<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
session_start();
include "konek.php";
$sqlc = $con->query("select count(koreg) as hkor from hasil_vote");
$data = $sqlc->fetch_array();
?>
<div class="col-xs-12 col-md-8">
<div id="noprint">
<div class="alert alert-info" id="p2">
<button onClick="window.print()">Print</button><br />
Jumlah Siswa yang telah memilih: <?php echo $data['hkor'];?> <br />
<a href="?h=resetpoling" onclick="return confirm('Anda mau reset hasil poling?') && confirm('Apakah anda yakin mau reset hasil poling??');" class="label label-warning">Reset Hasil Poling</a>
</div>
</div>
</div>
<div id="printareaku">
<div class="col-xs-12 col-md-8" >
<h2 id="p1">Hasil Pemilihan Calon Ketua dan Wakil Ketua Osis</h2>
<table class="table table-striped table-bordered">
<thead>
	<tr>
		<th>Foto Calon</th>
		<th>Nama Calon</th>
		<th>Status</th>
		<th>Perolehan Suara</th>
		<!--<th>Aksi</th>-->
	</tr>
</thead>
<tbody>
<?php 
	$sql = $con->query("select *, case status when '1' then 'Calon Ketua' when '2' then 'Calon Wakil' end as asStat from calon");
	while ($row=$sql->fetch_array()){
?>
	<tr>
		<td><img src="img/<?php echo $row['fotoCalon'];?>" class='img-responsive' width=80></td>
		<td><?php echo $row['namaCalon'];?></td>
		<td><?php echo $row['asStat'];?></td>
		<td><strong><?php echo $row['hpoling'];?> Suara</strong></td>
	</tr>
	<?php 
	} 
	?>
	</tbody>
</table>
</div>
</div>