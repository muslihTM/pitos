<?php
include "konek.php";
?>
<div class="row">
	<?php
    $sqln = $con->query("SELECT namaCalon FROM calon");
    $sqlh = $con->query("SELECT hpoling FROM calon");
    
    ?>
    <div class="canvaschart" >
        <canvas id="demobar" width="50" height="50"></canvas>
    </div>
    <script  type="text/javascript">

    var ctx = document.getElementById("demobar").getContext("2d");
    var data = {
       labels: [<?php while ($p = $sqln->fetch_array()) { echo '"' . $p['namaCalon'] . '",';}?>],
       datasets: [
       {
         label: "Hasil Pemilihan Ketua Osis dan Wakil Ketua Osis",
         data: [<?php while ($r = $sqlh->fetch_array()) { echo '"' . $r['hpoling'] . '",';}?>],
         backgroundColor: [
         "rgba(59, 100, 222, 1)",
         "rgba(203, 222, 225, 0.9)",
         "rgba(102, 50, 179, 1)",
         "rgba(201, 29, 29, 1)",
         "rgba(81, 230, 153, 1)",
         "rgba(246, 34, 19, 1)"]
     }
     ]
 };

 var myBarChart = new Chart(ctx, {
   type: 'horizontalBar',
   data: data,
   options: {
       barValueSpacing: 1,
       scales: {
         yAxes: [{
             ticks: {
                 min: 0,
             }
         }],
         xAxes: [{
             gridLines: {
                 color: "rgba(0, 0, 0, 0)",
             }
         }]
     }
 }
});
 </script>


 <a href="excel_reporting.php" class="btn btn-success"><span class="glyphicon glyphicon-floppy-save"> Unduh Data</span></a>


</div>

