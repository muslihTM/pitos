<?php
include "konek.php";
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
header("Content-type: application/vnd-ms-excel");
 
// Mendefinisikan nama file ekspor "hasil-export.xls"
header("Content-Disposition: attachment; filename=Koreg.xls");
?>
<table border="1">
<?php 
	$tampil= $con->query("select koreg from koreg");
	while ($row=$tampil->fetch_array()){
?>    
	<tr><td><?php echo $row['koreg'];?></td></tr>
<?php } ?>
</table>