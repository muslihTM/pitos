<?php 
/*
--- Pilketos V.2018
--- created date : 19-06-2013
--- author : Muhammad Taufiq Muslih
--- email : muslih@smansara.com
--- blog : tnetter.wordpress.com
--- Note : Gunakan dengan bijak aplikasi untuk kebutuhan Pilihan Ketua Osisi, 
--- silahkan memodifikasi sesuai kebutuhan anda dengan tidak mengubah pembuat awal aplikasi ini, 
--- jika anda mengalami kesulitan silahkan kontak email saya 
--- atau anda bisa menghubungi saya pada kontak yang sudah saya sediakan
--- untuk kondisi yang memungkinkan penghapusan nama saya silahkan meminta ijin saya terlebih dahulu.
=======================================================================================================================================
change log :
---------------------------------------------------------------------------------------------------------------------------------------
22-Okt-2018 v.2018 :
--- Pembaharuan halaman admin
--- Ubah biodata calon ketua dan wakil ketua
--- Pembaharuan cetak kode registrasi dengan CSS Paper 
--- Pembaharuan Chart
--- Pembaharuan cetak hasil pemilihan
=======================================================================================================================================
*/
include "header.php"; 
?>

<?php  
if(!isset($_SESSION['evote'])) {
	?>
	<div class="top-content">

		<div class="inner-bg">
			<div class="container-fluid">
				<div class="row">
					<div class="col-sm-8 col-sm-offset-2 text">
						<h1><strong>PILKETOS</strong> ONLINE</h1>
						<div class="description">
							<p>

							</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-sm-offset-3 form-box">
						<div class="form-top">
							<div class="form-top-left">
								<h3>Masuk Untuk Memilih Ketua dan Wakil Ketua OSIS</h3>
								<p>Masukkan Kode Registrasi/Koreg yang Telah diterima:</p>
							</div>
							<div class="form-top-right">
								<i class="fa fa-lock"></i>
							</div>
						</div>
						<div class="form-bottom">

							<?php
							if (isset($_POST['Submit'])) {
								$koreg = $_POST['koreg'];

								$q = $con->query("select * from hasil_vote where koreg='$koreg'");
								$q2 = $con->query("select * from koreg where koreg='$koreg'");
								$dataNum=$q->num_rows;
								$dataNum2=$q2->num_rows;
								$qLogin=$q2->fetch_array();
								if (($dataNum==0) and ($dataNum2==1)) { 
									$_SESSION['evote'] = $qLogin['id'];
									$_SESSION['koreg'] = $qLogin['koreg'];
									header('location: form.php');
								}
								else  	echo "<p class='alert alert-danger'><strong>Gagal:</strong> Koreg Salah / Koreg Sudah Digunakan </strong></p>";
							}
							?>
							<?php 
							if(isset($_SESSION['reg01_msg'])){
								?>
								<div style="height: 10px;"></div>
								<div class="alert alert-danger">
									<span><center>
										<?php echo $_SESSION['reg01_msg'];
										unset($_SESSION['reg01_msg']); 
										?>
									</center></span>
								</div>
								<?php
							}
							?>

							<form role="form" action="" method="post" class="login-form">
								<div class="form-group">
									<label class="sr-only" for="form-username">Koreg</label>
									<input type="text" name="koreg" autocomplete="off" placeholder="Koreg..." class="form-username form-control" id="form-username" required>
								</div>
								<button type="submit" name="Submit" class="btn">Masuk</button>
							</form>
						</div>
					</div>
				</div>
				
				Copyright &copy 2016 - <?php echo date('Y');?> SMA Negeri 1 Jepara
			</div>
		</div>

	</div>

	<?php 
}else{
	header('location:form.php');
}
include "footer.php";
?>
