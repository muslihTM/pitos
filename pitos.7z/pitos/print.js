function printData()
{
   var divToPrint=document.getElementById("printArea");
   newWin= window.open("");
   newWin.document.write('admin?h=dacalon');
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData();
})