<?php
include "konek.php";
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Print Koreg</title>

    <!-- Bootstrap -->
    <link href="css.css" rel="stylesheet">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/paper.css">
    <script>
  window.print();

</script>
</head>
<?php 
	$koregperpage = 60;
	$querycount= $con->query("select count(koreg) as sumkoreg from koreg");
	$count = $querycount->fetch_array();
	$jumlahhalaman = ceil($count['sumkoreg']/$koregperpage);
	

	for ($i=1;$i<=$jumlahhalaman;$i++) { //perulangan untuk jumlah halaman
		$querytampil= $con->query("select koreg from koreg limit $i, $koregperpage"); //

?>

<body  class="A4" >
	<?php echo "Halaman ke-".$i;?>
<section class="sheet padding-10mm">
<?php 
	while ($row=$querytampil->fetch_array()){  // perulangan untuk menampilkan kode registrasi
?> 
	<div class="box"><?php echo $row['koreg'];?></div>
<?php } ?>
</section >
</body>
<?php 
	} 
?>
</html>