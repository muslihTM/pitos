<?php
$con = new mysqli("localhost","root","","sma1_pitos");

//cek error 
if ($con->connect_error) {
    die('Error : ('. $con->connect_errno .') '. $con->connect_error);
}

?>
