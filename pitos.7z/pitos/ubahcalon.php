<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
session_start();
include "konek.php";
$sql = $con->query("select *, case status when '1' then 'Calon Ketua' when '2' then 'Calon Wakil Ketua' end as asStat from calon where id_c='".$_GET['idc']."'");
$row = $sql->fetch_assoc();
?>
<h2 id="p1">Ubah/Ganti Calon</h2>
<form action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $row['id_c'];?>" >
<table class="table table-bordered">
<tr>
	<td>Nama Calon</td>
	<td><input type="text" class="form-control" name="namacalon" value="<?php echo $row['namaCalon'];?>" ></td>
</tr>
<tr>
	<td>Status</td>
	<td><select name="status" class="form-control">
			<option value="<?php echo $row['status'];?>"><?php echo $row['asStat'];?></option>
			<option value="1">Calon Ketua</option>
			<option value="2">Calon Wakil Ketua</option>
		</select>
	</td>
</tr>
<tr>
	<td>Foto Calon</td>
	<td><input type="file" name="file" class="form-control-file"/></td>
</tr>
<tr>
	<td></td>
	<td><img src="img/<?php echo $row['fotoCalon'];?>" class='img-responsive' width=80></td>
</tr>

<tr>
	<td></td>
	<td><input type="submit" name="simpan" value="Ubah Data" class="btn btn-primary"/></td>
</tr>
</table>
</form>
</div>

<?php 
if(isset($_POST['simpan'])) {
	$id 		= $_POST['id'];
	$namacalon	= $_POST['namacalon'];
	$status		= $_POST['status'];
	$file_loc = $_FILES['file']['tmp_name'];

	if (!isset($file_loc)) {
		$query=$con->query("UPDATE calon SET namaCalon='$namacalon', status='$status' where id_c='$id'");
		echo "<script>alert('Berhasil Merubah Tanpa Gambar!!');top.location='admin?h=inputcalon'</script>";
	} else {
		$file_loc = $_FILES['file']['tmp_name'];
		$file_name = $_FILES['file']['name'];
		move_uploaded_file($file_loc, 'img/'.$file_name);
		$query=$con->query("UPDATE calon SET namaCalon='$namacalon', status='$status', fotoCalon='$file_name' where id_c='$id'");
		echo "<script>alert('Berhasil Merubah!!');top.location='admin?h=inputcalon'</script>";

	}
}

?>