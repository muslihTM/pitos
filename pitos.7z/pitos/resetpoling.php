<?php
include "konek.php";

$reset = $con->query("UPDATE calon SET hpoling='0'");
echo "<script>alert('Reset Poling Berhasil!!');top.location='admin?h=hasilpoling'</script>";

