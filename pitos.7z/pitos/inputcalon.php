<?php 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
session_start();
include "konek.php";
$sqlc = $con->query("select count(koreg) as hkor from hasil_vote");
$data = $sqlc->fetch_array();
?>
<div class="col-xs-12 col-md-8" id="cetaksaja">
	<h2 id="p1">Daftar Calon</h2>
	<table class="table table-striped table-bordered">
		<thead>
			<tr>
				<th>Foto Calon</th>
				<th>Nama Calon</th>
				<th>Status</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			$sql = $con->query("select *, case status when '1' then 'Calon Ketua' when '2' then 'Calon Wakil' end as asStat from calon");
			while ($row=$sql->fetch_array()){
				?>
				<tr>
					<td><center><img src="img/<?php echo $row['fotoCalon'];?>" class='img-responsive' width=80></center></td>
					<td><?php echo $row['namaCalon'];?></td>
					<td><?php echo $row['asStat'];?></td>
					<td><a href="?h=ubahcalon&idc=<?php echo $row['id_c'];?>" class="btn btn-warning">Ubah</a></td>
				</tr>
				<?php 
			} 
			?>
		</tbody>
	</table>
</div>