<?php 
include "konek.php";
$truncatekoreg = $con->query("truncate koreg");
$truncatehasil = $con->query("truncate hasil_vote");
echo "<script>alert('Reset Tabel korega dan hasil vote Berhasil!!');</script>";

