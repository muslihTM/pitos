<?php
include "konek.php";
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$sql=$con->query("select * from counter");
$row1=$sql->fetch_array();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="refresh" content="10">
	<title>E-Vooting Pemilihan Wakil Kepala Sekolah SMA Negeri 1 Jepara</title>

	<!-- Bootstrap -->
	<link href="css.css" rel="stylesheet">
	<style>
	.reporting { 
		margin-left: 10px;
		padding: 10px;
	}
	</style>
</head>
<body>
	<div class="container">
		<h1>PEMILIH YANG SUDAH MEMILIH</h1>
		<hr />
		<?php 
		$sql=$con->query("select * from counter");
		while ($row=$sql->fetch_array()){
			echo "<div class='' >";
			echo "<div class='box-counter'>";
			echo "<div class='c-box-nama'>No.".$row['idco']."</div>";
			echo "<div class=\"c-box-counter\">".$row['nilai']." Pemilih";
			echo "</div></div>";
		}
		?>
	</div>
	<script src="boot/js/jquery.min.js"></script>
	<script src="boot/js/bootstrap.min.js"></script>
</body>
</html>