<?php

function acakangkahuruf($panjang)
{
    $karakter= 'AMBNCODPEQFRGWHTIUJVKWLX1234567890';
    $string = $kode;
    for ($i = 0; $i < $panjang; $i++) {
	$pos = rand(0, strlen($karakter)-1);
	$string .= $karakter{$pos};
    }
    return $string;
}
acakangkahuruf(10)