	<meta http-equiv="refresh" content="2">
	        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">

<div class="container">
<h2><strong>Generate</strong> Koreg</h2>
<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
$hostname = 'localhost'; 
$username = 'root'; 
$password = ''; 
$database = 'sma1_pitos'; 
try
{
	$dbh = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
 
}
catch(PDOException $e)
{
	echo $e->getMessage();
}
$query = $dbh->query('SELECT MAX(koreg) as kodex  FROM  koreg'); 
$data = $query->fetch();
$kode = $data['kodex'];
function acakangkahuruf($panjang)
{
    $karakter= 'AMBNCODPEQFRGWHTIUJVKWLX1234567890';
    $string = $kode;
    for ($i = 0; $i < $panjang; $i++) {
	$pos = rand(0, strlen($karakter)-1);
	$string .= $karakter{$pos};
    }
    return $string;
}
echo "Koreg Baru :".acakangkahuruf(6);

$q = $dbh->query("select count(koreg) as itung from koreg");
$d = $q->fetch();
echo "<br />Jumlah Koreg Tersedia :".$count = $d['itung'];

$query = $dbh->query("insert into koreg values('','".acakangkahuruf(6)."')");
?>
</div>