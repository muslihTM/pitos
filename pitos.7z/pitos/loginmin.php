        <div class="top-content">   	
          <div class="inner-bg">
            <div class="container">
              <div class="row">
                <div class="col-sm-8 col-sm-offset-2 text">
                  <h1><strong>PILKETOS</strong> ONLINE</h1>
                  <div class="description">
                   <p>
                    
                   </p>
                 </div>
               </div>
             </div>
             <div class="row">
              <div class="col-sm-6 col-sm-offset-3 form-box">
               <div class="form-top">
                <div class="form-top-left">
                 <h3>Hii Admin Pilketos</h3>
                 <p>Masukkan Username dan Password:</p>
               </div>
               <div class="form-top-right">
                 <i class="fa fa-lock"></i>
               </div>
             </div>
             <div class="form-bottom">
              <?php
              if (isset($_POST['Submit'])) {
                $user = $_POST['usera'];
                $password = $_POST['pass'];


                if ($user == "minto" && $password == "minta") { 
                 $_SESSION['evota'] = $user;
                 
                 echo '<script type="text/javascript">top.location="admin";</script>';
               }
               else  	echo "<p class='alert alert-danger'><strong>Gagal:</strong> User n Pass salah loh </strong></p>";
             }
             ?>			
             <form role="form" action="" method="post" class="login-form">
              <div class="form-group">
               <label class="sr-only" for="form-username">Username</label>
               <input type="text" name="usera" autocomplete="off" placeholder="Username" class="form-username form-control" id="form-username" required>
             </div>
             <div class="form-group">
               <label class="sr-only" for="form-username">Password</label>
               <input type="password" name="pass" autocomplete="off" placeholder="Password" class="form-username form-control" id="form-username" required>
             </div>
             <button type="submit" name="Submit" class="btn">Masuk</button>
           </form>
         </div>
       </div>
     </div>
     
     Copyright &copy 2016 - <?php echo date('Y');?> SMA Negeri 1 Jepara
   </div>
 </div>
 
</div>
