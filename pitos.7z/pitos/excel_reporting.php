<?php
// Fungsi header dengan mengirimkan raw data excel
header("Content-type: application/vnd-ms-excel");
 
// Mendefinisikan nama file ekspor "hasil-export.xls"
header("Content-Disposition: attachment; filename=hasil-Perolehan-suara.xls");

?>
<h1>Rekaptulasi Perolehan Pemilihan Wakil Kepala Sekolah Tahap 1</h1>
<table border="1">
<tr>
<td>No</td>
<td>Nama</td>
<td>Jumlah Suara</td>
</tr>
<?php 
include "konek.php";

$sql= $con->query("select * from calon order by hpoling DESC");
while ($row=$sql->fetch_array()) {
?>
<tr>
<td><?php echo $row['id_c'];?></td>
<td><?php echo $row['namaCalon'];?></td>
<td><?php echo $row['hpoling'];?></td>
</tr>
<?php } 
$sql->free();
?>
</table>