    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="?">PITOS</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="?h=inputcalon">Data Calon</a></li>
            <li><a href="?h=hasilpoling">Hasil Poling</a></li>
            <li><a href="?h=generate" target="_blank">Generate Koreg</a></li>
            <li><a href="printkoreg.php" target="_blank">Download Koreg Excel</a></li>
            <li><a href="destroy.php">Keluar</a></li>

          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <div class="cadmin"></div>
    <div class="container">
        <?php 
        if (empty($_GET['h'])) {
          $_GET['h']="reporting"; include "".$_GET['h'].".php";
        } else {
         include  "".$_GET['h'].".php"; }
         ?>
     </div>
