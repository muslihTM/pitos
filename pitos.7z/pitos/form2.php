<form name="form1" action="" method="post" >
	<?php 
	$tampil= $con->query("select id_c,namaCalon,fotoCalon from calon where status='1'");
	while ($row=$tampil->fetch_array()){
	echo "<div class='' >
			<div class='c-box'>";
		echo "<div class='c-box-nama'>".$row['namaCalon']."</div>";
		echo "<img src=img/".$row['fotoCalon']." class='img-responsive' width=100 >";
		echo '<div class="c-box-cek"><div class="checkbox checkbox-success">';
	echo "<input type='checkbox' name='plh[]' value='".$row['id_c']."')';> <label for=\"checkbox3\">PILIH</label></div>";
	echo "</div></div>";
	echo "<input type=hidden name='koreg' value='".$_SESSION['koreg']."'>";
	}
	$tampil->free();
	//$con->close();
	?>
	<input type="submit" class="btn2 btn-primary" name="simpan" value="SIMPAN" />
	</form>
	</div>
	</div>
	<?php
	if (isset($_POST['simpan'])) {
	$idc= $_POST['plh'];
	$koreg= $_POST['koreg'];
	for ($i=0; $i<count($idc);$i++) {
		
		$insert="insert into hasil_vote values('','$koreg','".$idc[$i]."')";
		//echo $insert."<br />";
		$update="update calon set hpoling=hpoling+1 where id_c='".$idc[$i]."'";
		$sql=$con->query($insert);
		$sqlu=$con->query($update);
		
	}
	$counter="insert into counter values('',1)";
	$sqlc=$con->query($counter);
	if ($sql) {
		echo "<script>alert('Terima Kasih Anda Sudah Meggunakan Hak Suara');top.location='destroy.php';</script>";
	} else {
		echo "<script>alert('Anda Golput ya.???');</script>";
	}
	$con->close();
	}
	echo "<a href='destroy.php'>Batalkan</a>"
	?>