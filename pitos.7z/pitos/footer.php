        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        <script>
        <!-- Validation radiobutton -->
        $('#submit').click(function(){
            if (!$("input[name='ketua']:checked").val()) {
             alert('Anda Belum memilih Calon Ketua!');
             return false;
         }
         else if  (!$("input[name='waket']:checked").val()) {
             alert('Anda Belum memilih Calon Wakil Ketua!');
             return false;
         } 
     })
        </script>
        <script>
        $(document).ready(function () {
            $("input[type='checkbox']").change(function () {
                var maxAllowed = 1;
                var cnt = $("input[type='checkbox']:checked").length;
                if (cnt > maxAllowed) {
                    $(this).prop("checked", "");
                    alert('Anda Hanya Dapat Memilih ' + maxAllowed + ' Pilihan!!');
                }
            });
        });	
        </script>

</body>
</html>