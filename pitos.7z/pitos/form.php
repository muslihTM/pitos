<?php 
include "header.php";
if (isset($_SESSION['evote'])) {
	?>
<div class="container box-pilihan">
	<div class="box-pilihan">
	<div class="form-top">
		<div class="form-top-left">
			<h3>PILIH CALON KETUA DAN WAKIL KETUA OSIS PERIODE 2018/2019</h3>
			<p>KLIK PADA SALAH SATU GAMBAR CALON KETUA OSIS </p>
		</div>
	</div>
	<form name="form1" action="" method="post" id="form1">
		<div class="row">
		<div class="col-xs-6">
			<div class="title1">CALON KETUA OSIS</div>
			<?php 
			$tampil= $con->query("select id_c,namaCalon,fotoCalon from calon where status='1'");
			while ($row=$tampil->fetch_array()){
				?>
				<div class="box-container">
					<div class="box-konten">
						<div class="namacalon"><?php echo $row['namaCalon'];?></div>
						<div class="inside">
							<img src="img/<?php echo $row['fotoCalon'];?>" class='img-responsive' width=120 >
						</div>
						<input type="radio" id="test<?php echo $row['id_c'];?>" name="ketua" value="<?php echo $row['id_c'];?>">
						<label for="test<?php echo $row['id_c'];?>">Pilih</label>
				<!-- <input type="radio" id="s-option" name="plh[]">
				<label for="s-option"> Pilih <?php echo $row['id_c'];?></label>-->

			</div>
		</div>
		<?php } ?>
	</div>
	<div class="col-xs-6">
		<div class="title1">CALON WAKIL KETUA OSIS</div>
		<?php 
		$tampil= $con->query("select id_c,namaCalon,fotoCalon from calon where status='2'");
		while ($row=$tampil->fetch_array()){
			?>
			<div class="box-container">
				<div class="box-konten">
					<div class="namacalon"><?php echo $row['namaCalon'];?></div>
					<div class="inside">
						<img src="img/<?php echo $row['fotoCalon'];?>" class='img-responsive' width=120 >
					</div>
					<input type="radio" id="test<?php echo $row['id_c'];?>" name="waket" value="<?php echo $row['id_c'];?>">
					<label for="test<?php echo $row['id_c'];?>">Pilih</label>

				</div>
			</div>
			<?php } ?>

		</div>
	</div>
	<div class="row">
			<div class="alert alert-info">
				<b>Perhatian!!</b><br />
				<ul>
					<li>Pilih Calon dengan klik tulisan pilih hingga berwarna Pink</li>
					<li>Klik Tombol "Simpan Pilihan" untuk Menyimpan Pilihan</li>

				</ul>
			</div>
			<input type="hidden" name="koreg" value="<?php echo $_SESSION['koreg']; ?>">
			<button type="submit" class="btn" form="form1" name="simpanwa" id="submit" />SIMPAN PILIHAN</button>
	</div>
	<p></p>
	</form>
	</div>
</div>

<?php
if (isset($_POST['simpanwa'])) {
	$idc= $_POST['ketua'];
	$idcc= $_POST['waket'];
	$koreg= $_POST['koreg'];
	$ip = $_SERVER['REMOTE_ADDR'];
	
	// SIMPAN HASIL PILIHAN
	$insert1="insert into hasil_vote values('','".$koreg."','".$idc."','".$idcc."',NOW(),'".$ip."')";
	// UBAH HASIL PEROLEHAN
	$update1="update calon set hpoling=hpoling+1 where id_c='".$idc."'";
	$update2="update calon set hpoling=hpoling+1 where id_c='".$idcc."'";
	//VALIDASI KOREG (Koneksi terputus, reload browser, dll)
	$q = $con->query("select koreg from hasil_vote where koreg='".$koreg."'");
	$num = $q->num_rows;
	if ($num > 0) {
		echo "<script>top.location='destroy.php';</script>";
	} else { 
		$sql1=$con->query($insert1);
		$sqlu1=$con->query($update1);
		$sqlu2=$con->query($update2);

		if ($sql1) {
			echo "<script>alert('Terima Kasih, Sudah Memilih, Klik OK');top.location='destroy.php';</script>";
		} 
		$con->close();
	}
} 



} else {
	header('location: index.php'); 
	//echo "<script>top.location='index.php';</script>";
}
include "footer.php"; 
?>